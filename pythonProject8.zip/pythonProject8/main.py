class User :
    def __init__(self, username: str, email: str):
        self.username = username
        self.email = email
        self.password = None
        self.is_active = False

    def register(self, password):
        self.password = password
        self.is_active = True
        print(f'User {self.username} registered')


    def check_password(self, password):
        return self.password == password

class AdminUser(User):
    def __inint__(self, username, email, password):
        super().__init__(username, email, password)
        self.privileges = []


    def grand_privilege(self, privilege):
        self.privileges.append(privilege)
        print(f'You got {privilege} to {self.username}')


class RegistrationSystem:
    def __init__(self):
        self.users = []


    def register_user(self, username, email, password):
        user = User(username, email)
        user.register(password)
        self.users.append(user)


    def register_admin(self, username, email, password):
        admin = AdminUser(username, email)
        admin.register(password)
        admin.grand_privilege("full access")
        self.users.append(admin)


    def list_users(self):
        for user in self.users:
            print(f'Username: {user.username}, Email: {user.email}, Active: {user.is_active}')



registration_system = RegistrationSystem()
registration_system.list_users()